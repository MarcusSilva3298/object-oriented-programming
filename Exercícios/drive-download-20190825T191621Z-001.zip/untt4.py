L = [1, 2, 3, 4, 2]

def repetidos(l):
    for i in l:
        n = l.count(i)
        if n > 1:
            print('Existe(m) elemento(s) repetido(s)')
            return True
    print('Não existem elementos repetidos')
    return False

def ordenada(l):
    l1 = l.copy()
    l1.sort()
    if l == l1:
        print('Lista ordenada')
        return True
    else:
        print('Lista não ordenada')
        return False

def MatrizIdentidade(n):
    M =[None]*n
    for i in range(0, n):
        l = ['0']*n
        l[i] = 1
        M[i] = l
    return M


print('--------------------------------')
print()


#repetidos(L)
#ordenada(L)
print(MatrizIdentidade(3))



print()
print('--------------------------------')

